<h1><?php echo $welcome; ?></h1>
