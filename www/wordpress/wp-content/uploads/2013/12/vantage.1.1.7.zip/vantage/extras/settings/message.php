<?php
$theme = basename( get_template_directory() );
printf( __("I hope %s is working well for you! Sign up to <a href='%s' target='_blank'>our newsletter</a> if you'd like more free themes and goodies.", 'vantage'), ucfirst($theme), 'http://eepurl.com/hbvhM');